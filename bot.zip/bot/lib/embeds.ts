import { EmbedBuilder, User } from "discord.js";
import { Colors, Emojis } from "../config";

export function successEmbed(title: string, description: string): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(Colors.SUCCESS)
    .setTitle(`${Emojis.CHECK} ${title}`)
    .setDescription(description)
    .setTimestamp();
}

export function errorEmbed(title: string, description: string): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(Colors.ERROR)
    .setTitle(`${Emojis.CROSS} ${title}`)
    .setDescription(description)
    .setTimestamp();
}

export function warnEmbed(title: string, description: string): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(Colors.WARNING)
    .setTitle(`${Emojis.WARN} ${title}`)
    .setDescription(description)
    .setTimestamp();
}

export function infoEmbed(title: string, description: string): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(Colors.INFO)
    .setTitle(`${Emojis.STAR} ${title}`)
    .setDescription(description)
    .setTimestamp();
}

export function mafiaEmbed(title: string, description: string): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(Colors.RED)
    .setTitle(`${Emojis.MAFIA} ${title}`)
    .setDescription(description)
    .setFooter({ text: "Mafia Roleplay • Sistema de Mafias" })
    .setTimestamp();
}

export function economyEmbed(title: string, description: string): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(Colors.GOLD)
    .setTitle(`${Emojis.MONEY} ${title}`)
    .setDescription(description)
    .setFooter({ text: "Mafia Roleplay • Economía" })
    .setTimestamp();
}

export function modEmbed(title: string, description: string, moderator: User): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(Colors.RED)
    .setTitle(`${Emojis.MOD} ${title}`)
    .setDescription(description)
    .setFooter({ text: `Moderador: ${moderator.tag}`, iconURL: moderator.displayAvatarURL() })
    .setTimestamp();
}

export function ticketEmbed(title: string, description: string): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(Colors.PRIMARY)
    .setTitle(`${Emojis.TICKET} ${title}`)
    .setDescription(description)
    .setFooter({ text: "Mafia Roleplay • Sistema de Tickets" })
    .setTimestamp();
}

export function logEmbed(title: string, description: string, color: number = Colors.INFO): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(color)
    .setTitle(`${Emojis.LOG} ${title}`)
    .setDescription(description)
    .setTimestamp();
}

export function profileEmbed(user: User, balance: number, bank: number, level: number, xp: number, mafiaName: string | null): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(Colors.GOLD)
    .setTitle(`${Emojis.CROWN} Perfil de ${user.username}`)
    .setThumbnail(user.displayAvatarURL({ size: 256 }))
    .addFields(
      { name: `${Emojis.MONEY} Balance`, value: `$${balance.toLocaleString()}`, inline: true },
      { name: `${Emojis.BANK} Banco`, value: `$${bank.toLocaleString()}`, inline: true },
      { name: `${Emojis.STAR} Nivel`, value: `${level} (${xp} XP)`, inline: true },
      { name: `${Emojis.MAFIA} Mafia`, value: mafiaName ?? "Sin mafia", inline: true },
    )
    .setFooter({ text: "Mafia Roleplay" })
    .setTimestamp();
}
