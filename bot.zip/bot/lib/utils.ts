import { GuildMember, PermissionFlagsBits, TextChannel, Guild, EmbedBuilder } from "discord.js";
import { getGuild } from "../database/models/Guild";
import { logger } from "./logger";

export function formatMoney(amount: number): string {
  return `$${amount.toLocaleString("es-ES")}`;
}

export function formatDuration(ms: number): string {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  if (hours > 0) return `${hours}h ${minutes % 60}m`;
  if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
  return `${seconds}s`;
}

export function generateId(prefix: string = ""): string {
  return `${prefix}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`.toUpperCase();
}

export function hasPermission(member: GuildMember, permission: bigint): boolean {
  return member.permissions.has(permission) || member.permissions.has(PermissionFlagsBits.Administrator);
}

export async function sendLog(guild: Guild, embed: EmbedBuilder): Promise<void> {
  try {
    const config = await getGuild(guild.id);
    if (!config.logChannel) return;
    const channel = guild.channels.cache.get(config.logChannel) as TextChannel | undefined;
    if (!channel) return;
    await channel.send({ embeds: [embed] });
  } catch (err) {
    logger.error({ err }, "Failed to send log");
  }
}

export function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

export function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function xpForNextLevel(level: number): number {
  return level * 100 * 1.5;
}

export function parseDuration(input: string): number | null {
  const match = input.match(/^(\d+)(s|m|h|d)$/i);
  if (!match) return null;
  const value = parseInt(match[1]!);
  const unit = match[2]!.toLowerCase();
  const multipliers: Record<string, number> = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
  return value * (multipliers[unit] ?? 0);
}
