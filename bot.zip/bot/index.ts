import "dotenv/config";
import express from "express";
import { BotClient } from "./client";
import { connectDatabase } from "./database/connection";
import { loadCommands } from "./handlers/commandHandler";
import { loadEvents } from "./handlers/eventHandler";
import { loadButtons } from "./handlers/buttonHandler";
import { loadSelectMenus } from "./handlers/selectMenuHandler";
import { loadModals } from "./handlers/modalHandler";
import { logger } from "./lib/logger";

const token = process.env["TOKEN"];
if (!token) throw new Error("TOKEN environment variable is required.");

const port = Number(process.env["PORT"] ?? 3000);

async function main(): Promise<void> {
  const client = new BotClient();

  loadCommands(client);
  loadEvents(client);
  loadButtons(client);
  loadSelectMenus(client);
  loadModals(client);

  // Start health server immediately so Replit artifact stays alive
  const app = express();
  app.get("/api/health", (_req, res) => {
    res.json({
      status: "ok",
      bot: client.user?.tag ?? "connecting",
      guilds: client.guilds.cache.size,
      ping: client.ws.ping,
    });
  });

  app.listen(port, () => {
    logger.info({ port }, "Health server listening");
  });

  // Connect to MongoDB in background — don't block bot startup
  connectDatabase()
    .then(() => logger.info("Database ready"))
    .catch((err) => logger.error({ err }, "MongoDB connection failed — commands requiring DB will fail. Check Atlas IP whitelist (allow 0.0.0.0/0)."));

  await client.login(token);

  process.on("SIGTERM", () => {
    logger.info("SIGTERM received, shutting down...");
    client.destroy();
    process.exit(0);
  });

  process.on("SIGINT", () => {
    logger.info("SIGINT received, shutting down...");
    client.destroy();
    process.exit(0);
  });
}

main().catch((err) => {
  logger.error({ err }, "Fatal error starting bot");
  process.exit(1);
});
