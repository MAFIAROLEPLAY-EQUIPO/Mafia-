import { Interaction } from "discord.js";
import type { BotClient } from "../client";
import { errorEmbed } from "../lib/embeds";
import { logger } from "../lib/logger";

export default {
  name: "interactionCreate",
  async execute(interaction: Interaction): Promise<void> {
    const client = interaction.client as BotClient;

    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;
      try {
        await command.execute(interaction);
      } catch (err) {
        logger.error({ err, command: interaction.commandName }, "Command error");
        const embed = errorEmbed("Error", "Ocurrió un error ejecutando este comando.");
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ embeds: [embed], ephemeral: true }).catch(() => null);
        } else {
          await interaction.reply({ embeds: [embed], ephemeral: true }).catch(() => null);
        }
      }
      return;
    }

    if (interaction.isAutocomplete()) {
      const command = client.commands.get(interaction.commandName);
      if (!command?.autocomplete) return;
      try { await command.autocomplete(interaction); } catch (err) { logger.error({ err }, "Autocomplete error"); }
      return;
    }

    if (interaction.isButton()) {
      const button = client.buttons.get(interaction.customId) ??
        [...client.buttons.values()].find((b) => interaction.customId.startsWith(b.customId));
      if (!button) return;
      try {
        await button.execute(interaction);
      } catch (err) {
        logger.error({ err, customId: interaction.customId }, "Button error");
        const embed = errorEmbed("Error", "Ocurrió un error procesando este botón.");
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ embeds: [embed], ephemeral: true }).catch(() => null);
        } else {
          await interaction.reply({ embeds: [embed], ephemeral: true }).catch(() => null);
        }
      }
      return;
    }

    if (interaction.isStringSelectMenu()) {
      const menu = client.selectMenus.get(interaction.customId) ??
        [...client.selectMenus.values()].find((m) => interaction.customId.startsWith(m.customId));
      if (!menu) return;
      try {
        await menu.execute(interaction);
      } catch (err) {
        logger.error({ err, customId: interaction.customId }, "SelectMenu error");
        const embed = errorEmbed("Error", "Ocurrió un error procesando este menú.");
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ embeds: [embed], ephemeral: true }).catch(() => null);
        } else {
          await interaction.reply({ embeds: [embed], ephemeral: true }).catch(() => null);
        }
      }
      return;
    }

    if (interaction.isModalSubmit()) {
      const modal = client.modals.get(interaction.customId) ??
        [...client.modals.values()].find((m) => interaction.customId.startsWith(m.customId));
      if (!modal) return;
      try {
        await modal.execute(interaction);
      } catch (err) {
        logger.error({ err, customId: interaction.customId }, "Modal error");
        const embed = errorEmbed("Error", "Ocurrió un error procesando este formulario.");
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ embeds: [embed], ephemeral: true }).catch(() => null);
        } else {
          await interaction.reply({ embeds: [embed], ephemeral: true }).catch(() => null);
        }
      }
      return;
    }
  },
};
