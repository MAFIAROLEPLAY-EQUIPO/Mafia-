import { Client, ActivityType } from "discord.js";
import type { BotClient } from "../client";
import { registerCommands } from "../handlers/commandHandler";
import { logger } from "../lib/logger";
import { Emojis } from "../config";

export default {
  name: "ready",
  once: true,
  async execute(readyClient: Client<true>): Promise<void> {
    const client = readyClient as BotClient;
    logger.info(`${Emojis.MAFIA} Bot online: ${client.user.tag}`);

    await registerCommands(client);

    client.user.setPresence({
      status: "online",
      activities: [{ name: "Mafia Roleplay 🔫", type: ActivityType.Playing }],
    });

    logger.info({ guilds: client.guilds.cache.size }, "Bot ready");
  },
};
