import { GuildMember, EmbedBuilder, TextChannel } from "discord.js";
import { getGuild } from "../database/models/Guild";
import { Colors, Emojis } from "../config";
import { logger } from "../lib/logger";

export default {
  name: "guildMemberAdd",
  async execute(member: GuildMember): Promise<void> {
    try {
      const config = await getGuild(member.guild.id);

      if (config.welcomeChannel) {
        const channel = member.guild.channels.cache.get(config.welcomeChannel) as TextChannel | undefined;
        if (channel) {
          const message = (config.welcomeMessage ?? "Bienvenido/a {user} a **{server}**!")
            .replace("{user}", `<@${member.id}>`)
            .replace("{server}", member.guild.name)
            .replace("{memberCount}", member.guild.memberCount.toString());

          const embed = new EmbedBuilder()
            .setColor(Colors.RED)
            .setTitle(`${Emojis.MAFIA} ¡Nuevo miembro!`)
            .setDescription(message)
            .setThumbnail(member.user.displayAvatarURL({ size: 256 }))
            .addFields({ name: "Miembro #", value: `${member.guild.memberCount}`, inline: true })
            .setTimestamp();

          await channel.send({ embeds: [embed] });
        }
      }

      if (config.verifyRole) {
        // Do NOT auto-assign verify role — member must verify manually
      }
    } catch (err) {
      logger.error({ err, member: member.id }, "guildMemberAdd error");
    }
  },
};
