import mongoose, { Schema, Document } from "mongoose";

export interface IWarn extends Document {
  userId: string;
  guildId: string;
  moderatorId: string;
  reason: string;
  createdAt: Date;
}

const WarnSchema = new Schema<IWarn>(
  {
    userId: { type: String, required: true, index: true },
    guildId: { type: String, required: true, index: true },
    moderatorId: { type: String, required: true },
    reason: { type: String, required: true },
  },
  { timestamps: true }
);

export const Warn = mongoose.model<IWarn>("Warn", WarnSchema);
