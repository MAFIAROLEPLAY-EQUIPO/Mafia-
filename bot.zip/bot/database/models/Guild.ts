import mongoose, { Schema, Document } from "mongoose";

export interface IGuild extends Document {
  guildId: string;
  logChannel: string | null;
  verifyChannel: string | null;
  verifyRole: string | null;
  ticketCategory: string | null;
  ticketSupportRole: string | null;
  muteRole: string | null;
  welcomeChannel: string | null;
  welcomeMessage: string | null;
  createdAt: Date;
  updatedAt: Date;
}

const GuildSchema = new Schema<IGuild>(
  {
    guildId: { type: String, required: true, unique: true, index: true },
    logChannel: { type: String, default: null },
    verifyChannel: { type: String, default: null },
    verifyRole: { type: String, default: null },
    ticketCategory: { type: String, default: null },
    ticketSupportRole: { type: String, default: null },
    muteRole: { type: String, default: null },
    welcomeChannel: { type: String, default: null },
    welcomeMessage: { type: String, default: null },
  },
  { timestamps: true }
);

export const Guild = mongoose.model<IGuild>("Guild", GuildSchema);

export async function getGuild(guildId: string): Promise<IGuild> {
  let guild = await Guild.findOne({ guildId });
  if (!guild) {
    guild = await Guild.create({ guildId });
  }
  return guild;
}
