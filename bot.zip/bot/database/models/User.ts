import mongoose, { Schema, Document } from "mongoose";

export interface IUser extends Document {
  userId: string;
  guildId: string;
  balance: number;
  bank: number;
  lastDaily: Date | null;
  lastRob: Date | null;
  mafiaId: string | null;
  warnings: number;
  xp: number;
  level: number;
  createdAt: Date;
  updatedAt: Date;
}

const UserSchema = new Schema<IUser>(
  {
    userId: { type: String, required: true, index: true },
    guildId: { type: String, required: true, index: true },
    balance: { type: Number, default: 500 },
    bank: { type: Number, default: 0 },
    lastDaily: { type: Date, default: null },
    lastRob: { type: Date, default: null },
    mafiaId: { type: String, default: null },
    warnings: { type: Number, default: 0 },
    xp: { type: Number, default: 0 },
    level: { type: Number, default: 1 },
  },
  { timestamps: true }
);

UserSchema.index({ userId: 1, guildId: 1 }, { unique: true });

export const User = mongoose.model<IUser>("User", UserSchema);

export async function getUser(userId: string, guildId: string): Promise<IUser> {
  let user = await User.findOne({ userId, guildId });
  if (!user) {
    user = await User.create({ userId, guildId });
  }
  return user;
}
