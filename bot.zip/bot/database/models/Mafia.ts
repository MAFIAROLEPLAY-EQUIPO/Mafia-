import mongoose, { Schema, Document } from "mongoose";

export interface IMafia extends Document {
  mafiaId: string;
  guildId: string;
  name: string;
  leaderId: string;
  members: string[];
  bank: number;
  description: string;
  color: number;
  wins: number;
  losses: number;
  createdAt: Date;
  updatedAt: Date;
}

const MafiaSchema = new Schema<IMafia>(
  {
    mafiaId: { type: String, required: true, unique: true },
    guildId: { type: String, required: true, index: true },
    name: { type: String, required: true },
    leaderId: { type: String, required: true },
    members: { type: [String], default: [] },
    bank: { type: Number, default: 0 },
    description: { type: String, default: "Una mafia misteriosa..." },
    color: { type: Number, default: 0xc0392b },
    wins: { type: Number, default: 0 },
    losses: { type: Number, default: 0 },
  },
  { timestamps: true }
);

MafiaSchema.index({ guildId: 1, name: 1 }, { unique: true });

export const Mafia = mongoose.model<IMafia>("Mafia", MafiaSchema);
