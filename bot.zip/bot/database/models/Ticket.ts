import mongoose, { Schema, Document } from "mongoose";

export type TicketStatus = "open" | "claimed" | "closed";
export type TicketCategory = "soporte" | "reporte" | "apelacion" | "negocios";

export interface ITicket extends Document {
  ticketId: string;
  guildId: string;
  channelId: string;
  userId: string;
  claimedBy: string | null;
  category: TicketCategory;
  status: TicketStatus;
  subject: string;
  createdAt: Date;
  updatedAt: Date;
}

const TicketSchema = new Schema<ITicket>(
  {
    ticketId: { type: String, required: true, unique: true },
    guildId: { type: String, required: true, index: true },
    channelId: { type: String, required: true, unique: true },
    userId: { type: String, required: true },
    claimedBy: { type: String, default: null },
    category: {
      type: String,
      enum: ["soporte", "reporte", "apelacion", "negocios"],
      required: true,
    },
    status: {
      type: String,
      enum: ["open", "claimed", "closed"],
      default: "open",
    },
    subject: { type: String, required: true },
  },
  { timestamps: true }
);

export const Ticket = mongoose.model<ITicket>("Ticket", TicketSchema);
