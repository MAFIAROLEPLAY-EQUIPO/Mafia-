import mongoose from "mongoose";
import { logger } from "../lib/logger";

export async function connectDatabase(): Promise<void> {
  const uri = process.env["MONGO_URI"];
  if (!uri) {
    throw new Error("MONGO_URI environment variable is required but was not provided.");
  }

  mongoose.set("strictQuery", true);

  mongoose.connection.on("connected", () => logger.info("MongoDB connected successfully"));
  mongoose.connection.on("error", (err) => logger.error({ err }, "MongoDB connection error"));
  mongoose.connection.on("disconnected", () => logger.warn("MongoDB disconnected"));

  const options: mongoose.ConnectOptions = {
    serverSelectionTimeoutMS: 15000,
    connectTimeoutMS: 15000,
    socketTimeoutMS: 45000,
    maxPoolSize: 10,
  };

  await mongoose.connect(uri, options);
}

export async function disconnectDatabase(): Promise<void> {
  await mongoose.disconnect();
  logger.info("MongoDB disconnected gracefully");
}
