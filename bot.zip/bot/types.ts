import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  ButtonInteraction,
  StringSelectMenuInteraction,
  ModalSubmitInteraction,
  AutocompleteInteraction,
  Collection,
  Client,
} from "discord.js";

export interface Command {
  data: SlashCommandBuilder | Omit<SlashCommandBuilder, "addSubcommand" | "addSubcommandGroup">;
  execute: (interaction: ChatInputCommandInteraction) => Promise<void>;
  autocomplete?: (interaction: AutocompleteInteraction) => Promise<void>;
}

export interface Button {
  customId: string;
  execute: (interaction: ButtonInteraction) => Promise<void>;
}

export interface SelectMenu {
  customId: string;
  execute: (interaction: StringSelectMenuInteraction) => Promise<void>;
}

export interface Modal {
  customId: string;
  execute: (interaction: ModalSubmitInteraction) => Promise<void>;
}

export interface BotEvent {
  name: string;
  once?: boolean;
  execute: (...args: unknown[]) => Promise<void> | void;
}

export interface ExtendedClient extends Client {
  commands: Collection<string, Command>;
  buttons: Collection<string, Button>;
  selectMenus: Collection<string, SelectMenu>;
  modals: Collection<string, Modal>;
}
