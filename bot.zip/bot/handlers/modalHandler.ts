import type { BotClient } from "../client";
import { modals } from "../registry/modals";
import { logger } from "../lib/logger";

export function loadModals(client: BotClient): void {
  for (const modal of modals) {
    client.modals.set(modal.customId, modal);
    logger.info({ modal: modal.customId }, "Loaded modal");
  }
}
