import type { BotClient } from "../client";
import { events } from "../registry/events";
import { logger } from "../lib/logger";

export function loadEvents(client: BotClient): void {
  for (const event of events) {
    if (event.once) {
      client.once(event.name, (...args) => event.execute(...args));
    } else {
      client.on(event.name, (...args) => event.execute(...args));
    }
    logger.info({ event: event.name }, "Loaded event");
  }
}
