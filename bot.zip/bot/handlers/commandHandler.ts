import { REST, Routes } from "discord.js";
import type { BotClient } from "../client";
import { commands } from "../registry/commands";
import { logger } from "../lib/logger";

export function loadCommands(client: BotClient): void {
  for (const command of commands) {
    client.commands.set(command.data.name, command);
    logger.info({ command: command.data.name }, "Loaded command");
  }
  logger.info({ count: client.commands.size }, "All commands loaded");
}

export async function registerCommands(client: BotClient): Promise<void> {
  const token = process.env["TOKEN"];
  const clientId = client.user?.id;

  if (!token || !clientId) {
    logger.error("TOKEN or clientId missing, cannot register commands");
    return;
  }

  const rest = new REST({ version: "10" }).setToken(token);
  const body = [...client.commands.values()].map((c) => c.data.toJSON());

  try {
    logger.info({ count: body.length }, "Registering slash commands...");
    await rest.put(Routes.applicationCommands(clientId), { body });
    logger.info("Slash commands registered globally");
  } catch (err) {
    logger.error({ err }, "Failed to register commands");
  }
}
