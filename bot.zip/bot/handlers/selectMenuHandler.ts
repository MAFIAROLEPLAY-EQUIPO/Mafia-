import type { BotClient } from "../client";
import { selectMenus } from "../registry/selectMenus";
import { logger } from "../lib/logger";

export function loadSelectMenus(client: BotClient): void {
  for (const menu of selectMenus) {
    client.selectMenus.set(menu.customId, menu);
    logger.info({ menu: menu.customId }, "Loaded select menu");
  }
}
