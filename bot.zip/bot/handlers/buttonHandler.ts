import type { BotClient } from "../client";
import { buttons } from "../registry/buttons";
import { logger } from "../lib/logger";

export function loadButtons(client: BotClient): void {
  for (const button of buttons) {
    client.buttons.set(button.customId, button);
    logger.info({ button: button.customId }, "Loaded button");
  }
}
