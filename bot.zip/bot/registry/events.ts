import type { BotEvent } from "../types";

import ready from "../events/ready";
import interactionCreate from "../events/interactionCreate";
import guildMemberAdd from "../events/guildMemberAdd";

export const events: BotEvent[] = [ready, interactionCreate, guildMemberAdd];
