import type { Command } from "../types";

import setup from "../commands/admin/setup";
import ban from "../commands/moderation/ban";
import kick from "../commands/moderation/kick";
import mute from "../commands/moderation/mute";
import warn from "../commands/moderation/warn";
import clear from "../commands/moderation/clear";
import balance from "../commands/economy/balance";
import daily from "../commands/economy/daily";
import pay from "../commands/economy/pay";
import leaderboard from "../commands/economy/leaderboard";
import createmafia from "../commands/mafia/createmafia";
import joinmafia from "../commands/mafia/joinmafia";
import mafiainfo from "../commands/mafia/mafiainfo";
import deposit from "../commands/mafia/deposit";
import rob from "../commands/mafia/rob";
import ticket from "../commands/tickets/ticket";
import verify from "../commands/verification/verify";
import setlogs from "../commands/logs/setlogs";
import help from "../commands/utility/help";
import ping from "../commands/utility/ping";

export const commands: Command[] = [
  setup,
  ban,
  kick,
  mute,
  warn,
  clear,
  balance,
  daily,
  pay,
  leaderboard,
  createmafia,
  joinmafia,
  mafiainfo,
  deposit,
  rob,
  ticket,
  verify,
  setlogs,
  help,
  ping,
];
