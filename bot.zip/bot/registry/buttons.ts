import type { Button } from "../types";

import ticketClose from "../buttons/ticket_close";
import ticketClaim from "../buttons/ticket_claim";
import verifyAccept from "../buttons/verify_accept";

export const buttons: Button[] = [ticketClose, ticketClaim, verifyAccept];
