import type { Modal } from "../types";

import ticketModal from "../modals/ticket_modal";
import verifyModal from "../modals/verify_modal";

export const modals: Modal[] = [ticketModal, verifyModal];
