import type { SelectMenu } from "../types";

import ticketCategory from "../selectMenus/ticket_category";

export const selectMenus: SelectMenu[] = [ticketCategory];
