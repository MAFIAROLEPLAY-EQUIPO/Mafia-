import { ButtonInteraction, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } from "discord.js";
import { Ticket } from "../database/models/Ticket";
import { ticketEmbed, errorEmbed, logEmbed } from "../lib/embeds";
import { sendLog } from "../lib/utils";
import { Colors, Emojis } from "../config";
import type { Button } from "../types";

export default {
  customId: "ticket_claim",
  async execute(interaction: ButtonInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply({ ephemeral: true });

    const ticket = await Ticket.findOne({ channelId: interaction.channelId });
    if (!ticket) return void await interaction.editReply({ embeds: [errorEmbed("Error", "Este canal no es un ticket.")] });
    if (ticket.status === "claimed") return void await interaction.editReply({ embeds: [errorEmbed("Ya reclamado", `Este ticket ya fue reclamado por <@${ticket.claimedBy}>.`)] });

    const config = await import("../database/models/Guild").then((m) => m.getGuild(interaction.guild!.id));
    const isSupport = config.ticketSupportRole && (interaction.member as any)?.roles?.cache?.has(config.ticketSupportRole);
    const isAdmin = (interaction.member as any)?.permissions?.has(PermissionFlagsBits.Administrator);

    if (!isSupport && !isAdmin) {
      return void await interaction.editReply({ embeds: [errorEmbed("Sin permisos", "Solo el equipo de soporte puede reclamar tickets.")] });
    }

    ticket.claimedBy = interaction.user.id;
    ticket.status = "claimed";
    await ticket.save();

    await interaction.channel?.send({
      embeds: [ticketEmbed(`${Emojis.SHIELD} Ticket Reclamado`, `<@${interaction.user.id}> está atendiendo este ticket.`)],
    });

    await interaction.editReply({ embeds: [ticketEmbed("Reclamado", "Has reclamado este ticket exitosamente.")] });
    await sendLog(interaction.guild, logEmbed(`${Emojis.TICKET} Ticket reclamado`, `**Agente:** ${interaction.user.tag}\n**Ticket:** #${ticket.ticketId}`, Colors.INFO));
  },
} satisfies Button;
