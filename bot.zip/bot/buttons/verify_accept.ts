import { ButtonInteraction, GuildMember } from "discord.js";
import { getGuild } from "../database/models/Guild";
import { successEmbed, errorEmbed, logEmbed } from "../lib/embeds";
import { sendLog } from "../lib/utils";
import { Colors, Emojis } from "../config";
import type { Button } from "../types";

export default {
  customId: "verify_accept",
  async execute(interaction: ButtonInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply({ ephemeral: true });

    const config = await getGuild(interaction.guild.id);
    if (!config.verifyRole) {
      return void await interaction.editReply({ embeds: [errorEmbed("Sin configurar", "El rol de verificación no está configurado. Contacta a un admin.")] });
    }

    const member = interaction.member as GuildMember;
    if (member.roles.cache.has(config.verifyRole)) {
      return void await interaction.editReply({ embeds: [errorEmbed("Ya verificado", "Ya tienes el rol de verificado.")] });
    }

    try {
      await member.roles.add(config.verifyRole, "Verificación automática");
      await interaction.editReply({
        embeds: [successEmbed(`${Emojis.CHECK} ¡Verificado!`, "Has sido verificado exitosamente. ¡Bienvenido/a al servidor!")],
      });
      await sendLog(interaction.guild, logEmbed(`${Emojis.CHECK} Usuario verificado`, `**Usuario:** ${interaction.user.tag} (${interaction.user.id})`, Colors.SUCCESS));
    } catch {
      await interaction.editReply({ embeds: [errorEmbed("Error", "No se pudo asignar el rol. Verifica que el bot tenga permisos.")] });
    }
  },
} satisfies Button;
