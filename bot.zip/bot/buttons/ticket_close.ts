import { ButtonInteraction, PermissionFlagsBits, TextChannel } from "discord.js";
import { Ticket } from "../database/models/Ticket";
import { ticketEmbed, errorEmbed, logEmbed } from "../lib/embeds";
import { sendLog } from "../lib/utils";
import { Colors, Emojis } from "../config";
import type { Button } from "../types";

export default {
  customId: "ticket_close",
  async execute(interaction: ButtonInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply({ ephemeral: true });

    const ticket = await Ticket.findOne({ channelId: interaction.channelId });
    if (!ticket) return void await interaction.editReply({ embeds: [errorEmbed("Error", "Este canal no es un ticket.")] });

    const config = await import("../database/models/Guild").then((m) => m.getGuild(interaction.guild!.id));
    const isSupport = config.ticketSupportRole && (interaction.member as any)?.roles?.cache?.has(config.ticketSupportRole);
    const isOwner = ticket.userId === interaction.user.id;
    const isAdmin = (interaction.member as any)?.permissions?.has(PermissionFlagsBits.Administrator);

    if (!isSupport && !isOwner && !isAdmin) {
      return void await interaction.editReply({ embeds: [errorEmbed("Sin permisos", "Solo el creador o soporte puede cerrar el ticket.")] });
    }

    ticket.status = "closed";
    await ticket.save();

    await interaction.editReply({ embeds: [ticketEmbed("Ticket cerrado", "Este ticket será eliminado en 5 segundos.")] });

    await sendLog(interaction.guild, logEmbed(`${Emojis.TICKET} Ticket cerrado`, `**Canal:** ${interaction.channel}\n**Cerrado por:** ${interaction.user.tag}\n**Categoría:** ${ticket.category}`, Colors.WARNING));

    setTimeout(async () => {
      const ch = interaction.guild?.channels.cache.get(ticket.channelId) as TextChannel | undefined;
      await ch?.delete("Ticket cerrado").catch(() => null);
    }, 5000);
  },
} satisfies Button;
