import { Client, Collection, GatewayIntentBits, Partials } from "discord.js";
import type { Command, Button, SelectMenu, Modal } from "./types";

export class BotClient extends Client {
  commands: Collection<string, Command> = new Collection();
  buttons: Collection<string, Button> = new Collection();
  selectMenus: Collection<string, SelectMenu> = new Collection();
  modals: Collection<string, Modal> = new Collection();

  constructor() {
    super({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.GuildModeration,
      ],
      partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
    });
  }
}
