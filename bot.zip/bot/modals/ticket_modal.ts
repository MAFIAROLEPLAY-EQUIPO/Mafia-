import {
  ModalSubmitInteraction,
  ChannelType,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  OverwriteType,
} from "discord.js";
import { Ticket } from "../database/models/Ticket";
import { getGuild } from "../database/models/Guild";
import { ticketEmbed, logEmbed, errorEmbed } from "../lib/embeds";
import { generateId, sendLog } from "../lib/utils";
import { Colors, Emojis, Config } from "../config";
import type { Modal } from "../types";

export default {
  customId: "ticket_modal_",
  async execute(interaction: ModalSubmitInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply({ ephemeral: true });

    const categoryRaw = interaction.customId.replace("ticket_modal_", "") as string;
    const subject = interaction.fields.getTextInputValue("ticket_subject");
    const detail = interaction.fields.getTextInputValue("ticket_detail");

    const categoryLabels: Record<string, string> = {
      soporte: "Soporte General",
      reporte: "Reporte",
      apelacion: "Apelación",
      negocios: "Negocios",
    };

    const config = await getGuild(interaction.guild.id);
    const ticketId = generateId("TKT_");
    const channelName = `ticket-${interaction.user.username.toLowerCase().replace(/\s+/g, "-")}-${ticketId.slice(-4).toLowerCase()}`;

    let category = interaction.guild.channels.cache.find((c) => c.name === Config.TICKET_CATEGORY_NAME && c.type === ChannelType.GuildCategory);
    if (!category) {
      category = await interaction.guild.channels.create({
        name: Config.TICKET_CATEGORY_NAME,
        type: ChannelType.GuildCategory,
      });
    }

    const permissionOverwrites: any[] = [
      { id: interaction.guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
      { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
    ];

    if (config.ticketSupportRole) {
      permissionOverwrites.push({
        id: config.ticketSupportRole,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageChannels],
      });
    }

    const channel = await interaction.guild.channels.create({
      name: channelName,
      type: ChannelType.GuildText,
      parent: category.id,
      permissionOverwrites,
    });

    await Ticket.create({
      ticketId,
      guildId: interaction.guild.id,
      channelId: channel.id,
      userId: interaction.user.id,
      category: categoryRaw,
      subject,
    });

    const embed = new EmbedBuilder()
      .setColor(Colors.PRIMARY)
      .setTitle(`${Emojis.TICKET} Ticket — ${categoryLabels[categoryRaw] ?? categoryRaw}`)
      .setDescription([
        `**Abierto por:** <@${interaction.user.id}>`,
        `**Categoría:** ${categoryLabels[categoryRaw] ?? categoryRaw}`,
        `**Asunto:** ${subject}`,
        "",
        "**Descripción:**",
        detail,
        "",
        "> El equipo de soporte te atenderá pronto.",
      ].join("\n"))
      .setFooter({ text: `Ticket ID: ${ticketId}` })
      .setTimestamp();

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId("ticket_claim").setLabel("🛡️ Reclamar").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId("ticket_close").setLabel("🔒 Cerrar").setStyle(ButtonStyle.Danger)
    );

    await channel.send({ content: `<@${interaction.user.id}>${config.ticketSupportRole ? ` <@&${config.ticketSupportRole}>` : ""}`, embeds: [embed], components: [row] });

    await interaction.editReply({
      embeds: [ticketEmbed("Ticket Creado", `Tu ticket fue creado exitosamente: <#${channel.id}>`)],
    });

    await sendLog(interaction.guild, logEmbed(`${Emojis.TICKET} Nuevo ticket`, `**Usuario:** ${interaction.user.tag}\n**Categoría:** ${categoryLabels[categoryRaw]}\n**Asunto:** ${subject}\n**Canal:** <#${channel.id}>`, Colors.INFO));
  },
} satisfies Modal;
