import { ModalSubmitInteraction, GuildMember } from "discord.js";
import { getGuild } from "../database/models/Guild";
import { successEmbed, errorEmbed, logEmbed } from "../lib/embeds";
import { sendLog } from "../lib/utils";
import { Colors, Emojis } from "../config";
import type { Modal } from "../types";

export default {
  customId: "verify_modal",
  async execute(interaction: ModalSubmitInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply({ ephemeral: true });

    const config = await getGuild(interaction.guild.id);
    if (!config.verifyRole) {
      return void await interaction.editReply({ embeds: [errorEmbed("Sin configurar", "El sistema de verificación no está configurado.")] });
    }

    const member = interaction.member as GuildMember;
    if (member.roles.cache.has(config.verifyRole)) {
      return void await interaction.editReply({ embeds: [errorEmbed("Ya verificado", "Ya tienes el rol de verificado.")] });
    }

    try {
      await member.roles.add(config.verifyRole, "Verificación por modal");
      await interaction.editReply({
        embeds: [successEmbed(`${Emojis.CHECK} ¡Verificado!`, "Has sido verificado exitosamente. ¡Bienvenido/a!")],
      });
      await sendLog(interaction.guild, logEmbed(`${Emojis.CHECK} Usuario verificado (modal)`, `**Usuario:** ${interaction.user.tag} (${interaction.user.id})`, Colors.SUCCESS));
    } catch {
      await interaction.editReply({ embeds: [errorEmbed("Error", "No se pudo asignar el rol de verificado.")] });
    }
  },
} satisfies Modal;
