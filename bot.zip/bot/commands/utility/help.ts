import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { Colors, Emojis } from "../../config";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("help")
    .setDescription("Ver todos los comandos del bot"),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    await interaction.deferReply({ ephemeral: true });

    const embed = new EmbedBuilder()
      .setColor(Colors.RED)
      .setTitle(`${Emojis.MAFIA} Mafia Roleplay — Comandos`)
      .setThumbnail(interaction.client.user?.displayAvatarURL() ?? null)
      .addFields(
        {
          name: `${Emojis.SHIELD} Moderación`,
          value: "`/ban` `/kick` `/mute` `/warn` `/clear`",
          inline: false,
        },
        {
          name: `${Emojis.MONEY} Economía`,
          value: "`/balance` `/daily` `/pay` `/leaderboard`",
          inline: false,
        },
        {
          name: `${Emojis.MAFIA} Mafias`,
          value: "`/createmafia` `/joinmafia` `/mafiainfo` `/deposit` `/rob`",
          inline: false,
        },
        {
          name: `${Emojis.TICKET} Tickets`,
          value: "`/ticket panel`",
          inline: false,
        },
        {
          name: `${Emojis.CHECK} Verificación`,
          value: "`/verify panel`",
          inline: false,
        },
        {
          name: `${Emojis.LOG} Logs`,
          value: "`/setlogs`",
          inline: false,
        },
        {
          name: `${Emojis.STAR} Admin`,
          value: "`/setup logs` `/setup verificacion` `/setup tickets` `/setup bienvenida` `/setup ver`",
          inline: false,
        },
        {
          name: `${Emojis.FIRE} Utilidad`,
          value: "`/ping` `/help`",
          inline: false,
        },
      )
      .setFooter({ text: "Mafia Roleplay Bot • v1.0.0" })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  },
} satisfies Command;
