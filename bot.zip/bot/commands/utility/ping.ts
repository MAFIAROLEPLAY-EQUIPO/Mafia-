import { SlashCommandBuilder, ChatInputCommandInteraction } from "discord.js";
import { infoEmbed } from "../../lib/embeds";
import { Emojis } from "../../config";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Ver la latencia del bot"),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    await interaction.deferReply();
    const latency = Date.now() - interaction.createdTimestamp;
    const apiLatency = Math.round(interaction.client.ws.ping);

    await interaction.editReply({
      embeds: [infoEmbed(`${Emojis.FIRE} Pong!`, [
        `**Latencia del bot:** ${latency}ms`,
        `**Latencia API:** ${apiLatency}ms`,
      ].join("\n"))],
    });
  },
} satisfies Command;
