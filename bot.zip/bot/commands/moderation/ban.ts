import { SlashCommandBuilder, ChatInputCommandInteraction, PermissionFlagsBits, GuildMember } from "discord.js";
import { modEmbed, errorEmbed } from "../../lib/embeds";
import { sendLog } from "../../lib/utils";
import { Colors, Emojis } from "../../config";
import { logEmbed } from "../../lib/embeds";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("ban")
    .setDescription("Banea a un miembro del servidor")
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption((o) => o.setName("usuario").setDescription("Usuario a banear").setRequired(true))
    .addStringOption((o) => o.setName("razon").setDescription("Razón del ban").setRequired(false))
    .addIntegerOption((o) => o.setName("dias").setDescription("Días de mensajes a borrar (0-7)").setMinValue(0).setMaxValue(7).setRequired(false)),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.guild || !interaction.member) return;
    await interaction.deferReply({ ephemeral: true });

    const target = interaction.options.getMember("usuario") as GuildMember | null;
    const reason = interaction.options.getString("razon") ?? "Sin razón especificada";
    const days = interaction.options.getInteger("dias") ?? 0;

    if (!target) {
      return void await interaction.editReply({ embeds: [errorEmbed("Error", "No se encontró al usuario.")] });
    }
    if (!target.bannable) {
      return void await interaction.editReply({ embeds: [errorEmbed("Sin permisos", "No puedo banear a este usuario.")] });
    }
    if (target.id === interaction.user.id) {
      return void await interaction.editReply({ embeds: [errorEmbed("Error", "No puedes banearte a ti mismo.")] });
    }

    try {
      await target.send({
        embeds: [modEmbed(`Baneado de ${interaction.guild.name}`, `**Razón:** ${reason}`, interaction.user)],
      }).catch(() => null);

      await target.ban({ reason, deleteMessageSeconds: days * 86400 });

      const embed = modEmbed(`${Emojis.BAN} Usuario Baneado`, [
        `**Usuario:** ${target.user.tag} (${target.id})`,
        `**Moderador:** ${interaction.user.tag}`,
        `**Razón:** ${reason}`,
      ].join("\n"), interaction.user);

      await interaction.editReply({ embeds: [embed] });
      await sendLog(interaction.guild, logEmbed(`${Emojis.BAN} Ban aplicado`, `**Usuario:** ${target.user.tag}\n**Moderador:** ${interaction.user.tag}\n**Razón:** ${reason}`, Colors.ERROR));
    } catch {
      await interaction.editReply({ embeds: [errorEmbed("Error", "No se pudo ejecutar el ban.")] });
    }
  },
} satisfies Command;
