import { SlashCommandBuilder, ChatInputCommandInteraction, PermissionFlagsBits, GuildMember } from "discord.js";
import { modEmbed, errorEmbed, logEmbed, infoEmbed } from "../../lib/embeds";
import { sendLog } from "../../lib/utils";
import { Colors, Emojis } from "../../config";
import { Warn } from "../../database/models/Warn";
import { getUser } from "../../database/models/User";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("warn")
    .setDescription("Gestión de advertencias")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addSubcommand((sub) =>
      sub.setName("agregar").setDescription("Agregar advertencia")
        .addUserOption((o) => o.setName("usuario").setDescription("Usuario").setRequired(true))
        .addStringOption((o) => o.setName("razon").setDescription("Razón").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName("ver").setDescription("Ver advertencias de un usuario")
        .addUserOption((o) => o.setName("usuario").setDescription("Usuario").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName("limpiar").setDescription("Limpiar advertencias de un usuario")
        .addUserOption((o) => o.setName("usuario").setDescription("Usuario").setRequired(true))
    ),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply({ ephemeral: true });

    const sub = interaction.options.getSubcommand();
    const target = interaction.options.getMember("usuario") as GuildMember | null;
    if (!target) return void await interaction.editReply({ embeds: [errorEmbed("Error", "No se encontró al usuario.")] });

    if (sub === "agregar") {
      const reason = interaction.options.getString("razon", true);
      await Warn.create({ userId: target.id, guildId: interaction.guild.id, moderatorId: interaction.user.id, reason });
      const user = await getUser(target.id, interaction.guild.id);
      user.warnings += 1;
      await user.save();

      await interaction.editReply({
        embeds: [modEmbed(`${Emojis.WARN} Advertencia Añadida`, `**Usuario:** ${target.user.tag}\n**Razón:** ${reason}\n**Total warns:** ${user.warnings}`, interaction.user)],
      });
      await sendLog(interaction.guild, logEmbed(`${Emojis.WARN} Advertencia`, `**Usuario:** ${target.user.tag}\n**Moderador:** ${interaction.user.tag}\n**Razón:** ${reason}`, Colors.WARNING));

    } else if (sub === "ver") {
      const warns = await Warn.find({ userId: target.id, guildId: interaction.guild.id }).sort({ createdAt: -1 }).limit(10);
      if (!warns.length) return void await interaction.editReply({ embeds: [infoEmbed("Sin warns", `${target.user.tag} no tiene advertencias.`)] });

      const list = warns.map((w, i) => `**${i + 1}.** ${w.reason} — <@${w.moderatorId}>`).join("\n");
      await interaction.editReply({ embeds: [infoEmbed(`Advertencias de ${target.user.username}`, list)] });

    } else if (sub === "limpiar") {
      await Warn.deleteMany({ userId: target.id, guildId: interaction.guild.id });
      const user = await getUser(target.id, interaction.guild.id);
      user.warnings = 0;
      await user.save();
      await interaction.editReply({ embeds: [modEmbed("Warns limpiados", `Se limpiaron todos los warns de ${target.user.tag}`, interaction.user)] });
    }
  },
} satisfies Command;
