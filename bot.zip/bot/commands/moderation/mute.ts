import { SlashCommandBuilder, ChatInputCommandInteraction, PermissionFlagsBits, GuildMember } from "discord.js";
import { modEmbed, errorEmbed, logEmbed } from "../../lib/embeds";
import { sendLog, parseDuration } from "../../lib/utils";
import { Colors, Emojis } from "../../config";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("mute")
    .setDescription("Silencia a un miembro del servidor")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((o) => o.setName("usuario").setDescription("Usuario a silenciar").setRequired(true))
    .addStringOption((o) => o.setName("duracion").setDescription("Duración (ej: 10m, 1h, 1d)").setRequired(true))
    .addStringOption((o) => o.setName("razon").setDescription("Razón").setRequired(false)),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply({ ephemeral: true });

    const target = interaction.options.getMember("usuario") as GuildMember | null;
    const durationStr = interaction.options.getString("duracion", true);
    const reason = interaction.options.getString("razon") ?? "Sin razón especificada";

    if (!target) return void await interaction.editReply({ embeds: [errorEmbed("Error", "No se encontró al usuario.")] });
    if (!target.moderatable) return void await interaction.editReply({ embeds: [errorEmbed("Sin permisos", "No puedo silenciar a este usuario.")] });

    const duration = parseDuration(durationStr);
    if (!duration) return void await interaction.editReply({ embeds: [errorEmbed("Error", "Formato de duración inválido. Usa: 10m, 1h, 1d")] });
    if (duration > 2419200000) return void await interaction.editReply({ embeds: [errorEmbed("Error", "La duración máxima es 28 días.")] });

    await target.timeout(duration, reason);

    await interaction.editReply({
      embeds: [modEmbed(`${Emojis.MUTE} Usuario Silenciado`, `**Usuario:** ${target.user.tag}\n**Duración:** ${durationStr}\n**Razón:** ${reason}`, interaction.user)],
    });
    await sendLog(interaction.guild, logEmbed(`${Emojis.MUTE} Mute aplicado`, `**Usuario:** ${target.user.tag}\n**Duración:** ${durationStr}\n**Moderador:** ${interaction.user.tag}\n**Razón:** ${reason}`, Colors.WARNING));
  },
} satisfies Command;
