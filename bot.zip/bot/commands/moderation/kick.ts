import { SlashCommandBuilder, ChatInputCommandInteraction, PermissionFlagsBits, GuildMember } from "discord.js";
import { modEmbed, errorEmbed, logEmbed } from "../../lib/embeds";
import { sendLog } from "../../lib/utils";
import { Colors, Emojis } from "../../config";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("kick")
    .setDescription("Expulsa a un miembro del servidor")
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption((o) => o.setName("usuario").setDescription("Usuario a expulsar").setRequired(true))
    .addStringOption((o) => o.setName("razon").setDescription("Razón de la expulsión").setRequired(false)),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply({ ephemeral: true });

    const target = interaction.options.getMember("usuario") as GuildMember | null;
    const reason = interaction.options.getString("razon") ?? "Sin razón especificada";

    if (!target) return void await interaction.editReply({ embeds: [errorEmbed("Error", "No se encontró al usuario.")] });
    if (!target.kickable) return void await interaction.editReply({ embeds: [errorEmbed("Sin permisos", "No puedo expulsar a este usuario.")] });
    if (target.id === interaction.user.id) return void await interaction.editReply({ embeds: [errorEmbed("Error", "No puedes expulsarte a ti mismo.")] });

    await target.send({ embeds: [modEmbed(`Expulsado de ${interaction.guild.name}`, `**Razón:** ${reason}`, interaction.user)] }).catch(() => null);
    await target.kick(reason);

    await interaction.editReply({
      embeds: [modEmbed(`${Emojis.KICK} Usuario Expulsado`, `**Usuario:** ${target.user.tag}\n**Razón:** ${reason}`, interaction.user)],
    });
    await sendLog(interaction.guild, logEmbed(`${Emojis.KICK} Kick aplicado`, `**Usuario:** ${target.user.tag}\n**Moderador:** ${interaction.user.tag}\n**Razón:** ${reason}`, Colors.WARNING));
  },
} satisfies Command;
