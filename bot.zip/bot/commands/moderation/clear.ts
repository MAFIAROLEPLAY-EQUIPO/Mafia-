import { SlashCommandBuilder, ChatInputCommandInteraction, PermissionFlagsBits, TextChannel } from "discord.js";
import { successEmbed, errorEmbed } from "../../lib/embeds";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("clear")
    .setDescription("Elimina mensajes del canal")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption((o) => o.setName("cantidad").setDescription("Cantidad de mensajes (1-100)").setMinValue(1).setMaxValue(100).setRequired(true))
    .addUserOption((o) => o.setName("usuario").setDescription("Filtrar por usuario (opcional)").setRequired(false)),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply({ ephemeral: true });

    const amount = interaction.options.getInteger("cantidad", true);
    const user = interaction.options.getUser("usuario");
    const channel = interaction.channel as TextChannel;

    try {
      let messages = await channel.messages.fetch({ limit: amount });
      if (user) {
        messages = messages.filter((m) => m.author.id === user.id);
      }
      const deleted = await channel.bulkDelete(messages, true);
      await interaction.editReply({
        embeds: [successEmbed("Mensajes eliminados", `Se eliminaron **${deleted.size}** mensajes.`)],
      });
    } catch {
      await interaction.editReply({ embeds: [errorEmbed("Error", "No se pudieron eliminar los mensajes (son muy antiguos o hubo un error).")] });
    }
  },
} satisfies Command;
