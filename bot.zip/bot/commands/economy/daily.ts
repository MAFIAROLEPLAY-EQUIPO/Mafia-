import { SlashCommandBuilder, ChatInputCommandInteraction } from "discord.js";
import { getUser } from "../../database/models/User";
import { economyEmbed, errorEmbed } from "../../lib/embeds";
import { formatMoney, formatDuration } from "../../lib/utils";
import { Config, Emojis } from "../../config";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("daily")
    .setDescription("Reclama tu recompensa diaria"),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply();

    const user = await getUser(interaction.user.id, interaction.guild.id);
    const now = Date.now();
    const last = user.lastDaily?.getTime() ?? 0;
    const remaining = Config.DAILY_COOLDOWN - (now - last);

    if (remaining > 0) {
      return void await interaction.editReply({
        embeds: [errorEmbed("Daily no disponible", `Podrás reclamar tu daily en **${formatDuration(remaining)}**`)],
      });
    }

    const bonus = user.level * 100;
    const total = Config.DAILY_AMOUNT + bonus;
    user.balance += total;
    user.lastDaily = new Date();
    await user.save();

    await interaction.editReply({
      embeds: [
        economyEmbed(`${Emojis.MONEY} Daily Reclamado`, [
          `Has recibido **${formatMoney(total)}**`,
          `> Base: ${formatMoney(Config.DAILY_AMOUNT)} + Bonus nivel: ${formatMoney(bonus)}`,
          `\n${Emojis.DOLLAR} **Balance actual:** ${formatMoney(user.balance)}`,
        ].join("\n")),
      ],
    });
  },
} satisfies Command;
