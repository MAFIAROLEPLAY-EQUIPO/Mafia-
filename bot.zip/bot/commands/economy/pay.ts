import { SlashCommandBuilder, ChatInputCommandInteraction } from "discord.js";
import { getUser } from "../../database/models/User";
import { economyEmbed, errorEmbed } from "../../lib/embeds";
import { formatMoney, sendLog } from "../../lib/utils";
import { logEmbed } from "../../lib/embeds";
import { Colors, Emojis } from "../../config";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("pay")
    .setDescription("Envía dinero a otro usuario")
    .addUserOption((o) => o.setName("usuario").setDescription("Usuario al que enviar dinero").setRequired(true))
    .addIntegerOption((o) => o.setName("cantidad").setDescription("Cantidad a enviar").setMinValue(1).setRequired(true)),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply();

    const target = interaction.options.getUser("usuario", true);
    const amount = interaction.options.getInteger("cantidad", true);

    if (target.bot) return void await interaction.editReply({ embeds: [errorEmbed("Error", "No puedes enviar dinero a un bot.")] });
    if (target.id === interaction.user.id) return void await interaction.editReply({ embeds: [errorEmbed("Error", "No puedes enviarte dinero a ti mismo.")] });

    const sender = await getUser(interaction.user.id, interaction.guild.id);
    if (sender.balance < amount) return void await interaction.editReply({ embeds: [errorEmbed("Fondos insuficientes", `Solo tienes **${formatMoney(sender.balance)}**`)] });

    const receiver = await getUser(target.id, interaction.guild.id);
    sender.balance -= amount;
    receiver.balance += amount;
    await sender.save();
    await receiver.save();

    await interaction.editReply({
      embeds: [economyEmbed(`${Emojis.MONEY} Transferencia Exitosa`, [
        `**De:** <@${interaction.user.id}>`,
        `**Para:** <@${target.id}>`,
        `**Cantidad:** ${formatMoney(amount)}`,
        `\n${Emojis.DOLLAR} Tu balance: ${formatMoney(sender.balance)}`,
      ].join("\n"))],
    });
    await sendLog(interaction.guild, logEmbed("💸 Transferencia", `**De:** ${interaction.user.tag}\n**Para:** ${target.tag}\n**Cantidad:** ${formatMoney(amount)}`, Colors.GOLD));
  },
} satisfies Command;
