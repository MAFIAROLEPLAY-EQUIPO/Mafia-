import { SlashCommandBuilder, ChatInputCommandInteraction } from "discord.js";
import { getUser } from "../../database/models/User";
import { Mafia } from "../../database/models/Mafia";
import { profileEmbed, errorEmbed } from "../../lib/embeds";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("balance")
    .setDescription("Ver tu balance o el de otro usuario")
    .addUserOption((o) => o.setName("usuario").setDescription("Usuario (opcional)").setRequired(false)),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply();

    const target = interaction.options.getUser("usuario") ?? interaction.user;
    if (target.bot) return void await interaction.editReply({ embeds: [errorEmbed("Error", "Los bots no tienen balance.")] });

    const user = await getUser(target.id, interaction.guild.id);
    let mafiaName: string | null = null;
    if (user.mafiaId) {
      const mafia = await Mafia.findOne({ mafiaId: user.mafiaId });
      mafiaName = mafia?.name ?? null;
    }

    await interaction.editReply({
      embeds: [profileEmbed(target, user.balance, user.bank, user.level, user.xp, mafiaName)],
    });
  },
} satisfies Command;
