import { SlashCommandBuilder, ChatInputCommandInteraction } from "discord.js";
import { User } from "../../database/models/User";
import { economyEmbed } from "../../lib/embeds";
import { formatMoney } from "../../lib/utils";
import { Emojis } from "../../config";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("leaderboard")
    .setDescription("Top 10 usuarios más ricos del servidor"),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply();

    const top = await User.find({ guildId: interaction.guild.id })
      .sort({ balance: -1 })
      .limit(10);

    if (!top.length) {
      return void await interaction.editReply({ embeds: [economyEmbed("Leaderboard", "No hay datos aún.")] });
    }

    const medals = ["🥇", "🥈", "🥉"];
    const list = top
      .map((u, i) => `${medals[i] ?? `**${i + 1}.**`} <@${u.userId}> — ${formatMoney(u.balance)}`)
      .join("\n");

    await interaction.editReply({
      embeds: [economyEmbed(`${Emojis.RANK} Top Ricos — ${interaction.guild.name}`, list)],
    });
  },
} satisfies Command;
