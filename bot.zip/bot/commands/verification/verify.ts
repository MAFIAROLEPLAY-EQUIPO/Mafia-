import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} from "discord.js";
import { getGuild } from "../../database/models/Guild";
import { errorEmbed } from "../../lib/embeds";
import { Colors, Emojis } from "../../config";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("verify")
    .setDescription("Sistema de verificación")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((sub) =>
      sub.setName("panel").setDescription("Enviar panel de verificación al canal actual")
    ),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply({ ephemeral: true });

    const config = await getGuild(interaction.guild.id);
    if (!config.verifyRole) {
      return void await interaction.editReply({ embeds: [errorEmbed("Sin configurar", "Configura el rol de verificación primero con `/setup verificacion`.")] });
    }

    const embed = new EmbedBuilder()
      .setColor(Colors.RED)
      .setTitle(`${Emojis.SHIELD} Verificación — Mafia Roleplay`)
      .setDescription(
        [
          "**Bienvenido/a al servidor.**",
          "",
          "Para acceder al servidor debes verificarte.",
          "Haz click en el botón de abajo para completar la verificación.",
          "",
          "> Al verificarte aceptas las reglas del servidor.",
        ].join("\n")
      )
      .setFooter({ text: "Mafia Roleplay • Verificación automática" })
      .setTimestamp();

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId("verify_accept")
        .setLabel("✅ Verificarme")
        .setStyle(ButtonStyle.Success)
    );

    await interaction.channel?.send({ embeds: [embed], components: [row] });
    await interaction.editReply({ content: "Panel de verificación enviado." });
  },
} satisfies Command;
