import { SlashCommandBuilder, ChatInputCommandInteraction } from "discord.js";
import { getUser } from "../../database/models/User";
import { Mafia } from "../../database/models/Mafia";
import { mafiaEmbed, errorEmbed } from "../../lib/embeds";
import { formatMoney, generateId } from "../../lib/utils";
import { Config, Emojis } from "../../config";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("createmafia")
    .setDescription("Crea una nueva mafia")
    .addStringOption((o) => o.setName("nombre").setDescription("Nombre de la mafia").setMinLength(3).setMaxLength(30).setRequired(true))
    .addStringOption((o) => o.setName("descripcion").setDescription("Descripción de la mafia").setMaxLength(200).setRequired(false)),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply();

    const name = interaction.options.getString("nombre", true);
    const description = interaction.options.getString("descripcion") ?? "Una mafia misteriosa...";
    const user = await getUser(interaction.user.id, interaction.guild.id);

    if (user.mafiaId) {
      return void await interaction.editReply({ embeds: [errorEmbed("Ya en una mafia", "Debes abandonar tu mafia actual antes de crear una nueva.")] });
    }
    if (user.balance < Config.MAFIA_CREATE_COST) {
      return void await interaction.editReply({ embeds: [errorEmbed("Fondos insuficientes", `Necesitas **${formatMoney(Config.MAFIA_CREATE_COST)}** para crear una mafia.`)] });
    }

    const existing = await Mafia.findOne({ guildId: interaction.guild.id, name: { $regex: new RegExp(`^${name}$`, "i") } });
    if (existing) {
      return void await interaction.editReply({ embeds: [errorEmbed("Nombre en uso", "Ya existe una mafia con ese nombre.")] });
    }

    const mafiaId = generateId("MAFIA_");
    const mafia = await Mafia.create({ mafiaId, guildId: interaction.guild.id, name, leaderId: interaction.user.id, members: [interaction.user.id], description });
    user.balance -= Config.MAFIA_CREATE_COST;
    user.mafiaId = mafiaId;
    await user.save();

    await interaction.editReply({
      embeds: [mafiaEmbed(`${Emojis.CROWN} Mafia Creada`, [
        `**Nombre:** ${mafia.name}`,
        `**Descripción:** ${description}`,
        `**Líder:** <@${interaction.user.id}>`,
        `**Costo:** ${formatMoney(Config.MAFIA_CREATE_COST)}`,
        `\n> ¡Usa \`/joinmafia\` para reclutar miembros!`,
      ].join("\n"))],
    });
  },
} satisfies Command;
