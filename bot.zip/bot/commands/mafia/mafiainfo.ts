import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { getUser } from "../../database/models/User";
import { Mafia } from "../../database/models/Mafia";
import { errorEmbed } from "../../lib/embeds";
import { formatMoney } from "../../lib/utils";
import { Colors, Emojis } from "../../config";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("mafiainfo")
    .setDescription("Ver información de una mafia")
    .addStringOption((o) => o.setName("nombre").setDescription("Nombre de la mafia (o deja vacío para ver la tuya)").setRequired(false)),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply();

    let name = interaction.options.getString("nombre");
    let mafia;

    if (!name) {
      const user = await getUser(interaction.user.id, interaction.guild.id);
      if (!user.mafiaId) return void await interaction.editReply({ embeds: [errorEmbed("Sin mafia", "No perteneces a ninguna mafia.")] });
      mafia = await Mafia.findOne({ mafiaId: user.mafiaId });
    } else {
      mafia = await Mafia.findOne({ guildId: interaction.guild.id, name: { $regex: new RegExp(`^${name}$`, "i") } });
    }

    if (!mafia) return void await interaction.editReply({ embeds: [errorEmbed("No encontrada", "No se encontró esa mafia.")] });

    const memberList = mafia.members.slice(0, 10).map((id, i) => `${i + 1}. <@${id}>${id === mafia!.leaderId ? ` ${Emojis.CROWN}` : ""}`).join("\n");

    const embed = new EmbedBuilder()
      .setColor(mafia.color)
      .setTitle(`${Emojis.MAFIA} ${mafia.name}`)
      .setDescription(mafia.description)
      .addFields(
        { name: `${Emojis.CROWN} Líder`, value: `<@${mafia.leaderId}>`, inline: true },
        { name: `${Emojis.SHIELD} Miembros`, value: `${mafia.members.length}`, inline: true },
        { name: `${Emojis.BANK} Banco`, value: formatMoney(mafia.bank), inline: true },
        { name: `${Emojis.FIRE} Victorias`, value: `${mafia.wins}`, inline: true },
        { name: `${Emojis.SKULL} Derrotas`, value: `${mafia.losses}`, inline: true },
        { name: `${Emojis.KNIFE} Ratio`, value: mafia.losses > 0 ? (mafia.wins / mafia.losses).toFixed(2) : "∞", inline: true },
        { name: `${Emojis.SHIELD} Miembros (top 10)`, value: memberList || "Ninguno" },
      )
      .setFooter({ text: "Mafia Roleplay • Sistema de Mafias" })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  },
} satisfies Command;
