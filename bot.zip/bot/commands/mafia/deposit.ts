import { SlashCommandBuilder, ChatInputCommandInteraction } from "discord.js";
import { getUser } from "../../database/models/User";
import { Mafia } from "../../database/models/Mafia";
import { mafiaEmbed, errorEmbed } from "../../lib/embeds";
import { formatMoney } from "../../lib/utils";
import { Emojis } from "../../config";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("deposit")
    .setDescription("Deposita dinero en el banco de tu mafia")
    .addIntegerOption((o) => o.setName("cantidad").setDescription("Cantidad a depositar").setMinValue(1).setRequired(true)),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply();

    const amount = interaction.options.getInteger("cantidad", true);
    const user = await getUser(interaction.user.id, interaction.guild.id);

    if (!user.mafiaId) return void await interaction.editReply({ embeds: [errorEmbed("Sin mafia", "No perteneces a ninguna mafia.")] });
    if (user.balance < amount) return void await interaction.editReply({ embeds: [errorEmbed("Fondos insuficientes", `Solo tienes **${formatMoney(user.balance)}**`)] });

    const mafia = await Mafia.findOne({ mafiaId: user.mafiaId });
    if (!mafia) return void await interaction.editReply({ embeds: [errorEmbed("Error", "No se encontró tu mafia.")] });

    user.balance -= amount;
    mafia.bank += amount;
    await user.save();
    await mafia.save();

    await interaction.editReply({
      embeds: [mafiaEmbed(`${Emojis.BANK} Depósito a ${mafia.name}`, [
        `**Cantidad:** ${formatMoney(amount)}`,
        `**Banco de la mafia:** ${formatMoney(mafia.bank)}`,
        `**Tu balance:** ${formatMoney(user.balance)}`,
      ].join("\n"))],
    });
  },
} satisfies Command;
