import { SlashCommandBuilder, ChatInputCommandInteraction } from "discord.js";
import { getUser } from "../../database/models/User";
import { mafiaEmbed, errorEmbed } from "../../lib/embeds";
import { formatMoney, formatDuration, randomInt } from "../../lib/utils";
import { Config, Emojis } from "../../config";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("rob")
    .setDescription("Intenta robar dinero a otro usuario")
    .addUserOption((o) => o.setName("usuario").setDescription("Usuario al que robar").setRequired(true)),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply();

    const target = interaction.options.getUser("usuario", true);
    if (target.bot) return void await interaction.editReply({ embeds: [errorEmbed("Error", "No puedes robar a un bot.")] });
    if (target.id === interaction.user.id) return void await interaction.editReply({ embeds: [errorEmbed("Error", "No puedes robarte a ti mismo.")] });

    const robber = await getUser(interaction.user.id, interaction.guild.id);
    const victim = await getUser(target.id, interaction.guild.id);

    const now = Date.now();
    const lastRob = robber.lastRob?.getTime() ?? 0;
    const remaining = Config.ROB_COOLDOWN - (now - lastRob);
    if (remaining > 0) return void await interaction.editReply({ embeds: [errorEmbed("En espera", `Podrás robar de nuevo en **${formatDuration(remaining)}**`)] });
    if (victim.balance < Config.ROB_MIN_BALANCE) return void await interaction.editReply({ embeds: [errorEmbed("Objetivo pobre", `${target.username} no tiene suficiente dinero (mínimo ${formatMoney(Config.ROB_MIN_BALANCE)}).`)] });

    robber.lastRob = new Date();
    const success = Math.random() < Config.ROB_SUCCESS_CHANCE;

    if (success) {
      const stolen = randomInt(Math.floor(victim.balance * 0.05), Math.floor(victim.balance * 0.25));
      robber.balance += stolen;
      victim.balance -= stolen;
      await robber.save();
      await victim.save();

      await interaction.editReply({
        embeds: [mafiaEmbed(`${Emojis.GUN} ¡Robo exitoso!`, [
          `Robaste **${formatMoney(stolen)}** a <@${target.id}>`,
          `**Tu balance:** ${formatMoney(robber.balance)}`,
        ].join("\n"))],
      });
    } else {
      const fine = randomInt(100, 500);
      robber.balance = Math.max(0, robber.balance - fine);
      await robber.save();

      await interaction.editReply({
        embeds: [errorEmbed(`${Emojis.SKULL} ¡Robo fallido!`, [
          `Te pillaron robando a <@${target.id}>`,
          `**Multa:** ${formatMoney(fine)}`,
          `**Tu balance:** ${formatMoney(robber.balance)}`,
        ].join("\n"))],
      });
    }
  },
} satisfies Command;
