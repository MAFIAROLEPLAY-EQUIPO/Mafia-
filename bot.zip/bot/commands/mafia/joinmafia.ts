import { SlashCommandBuilder, ChatInputCommandInteraction } from "discord.js";
import { getUser } from "../../database/models/User";
import { Mafia } from "../../database/models/Mafia";
import { mafiaEmbed, errorEmbed } from "../../lib/embeds";
import { Config, Emojis } from "../../config";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("joinmafia")
    .setDescription("Únete a una mafia existente")
    .addStringOption((o) => o.setName("nombre").setDescription("Nombre de la mafia").setRequired(true)),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply();

    const name = interaction.options.getString("nombre", true);
    const user = await getUser(interaction.user.id, interaction.guild.id);

    if (user.mafiaId) {
      return void await interaction.editReply({ embeds: [errorEmbed("Ya en una mafia", "Debes abandonar tu mafia actual antes de unirte a otra.")] });
    }

    const mafia = await Mafia.findOne({ guildId: interaction.guild.id, name: { $regex: new RegExp(`^${name}$`, "i") } });
    if (!mafia) return void await interaction.editReply({ embeds: [errorEmbed("No encontrada", `No existe una mafia con el nombre **${name}**.`)] });
    if (mafia.members.length >= Config.MAFIA_MAX_MEMBERS) return void await interaction.editReply({ embeds: [errorEmbed("Mafia llena", `La mafia **${mafia.name}** está al máximo de miembros (${Config.MAFIA_MAX_MEMBERS}).`)] });
    if (mafia.members.includes(interaction.user.id)) return void await interaction.editReply({ embeds: [errorEmbed("Ya miembro", "Ya eres miembro de esta mafia.")] });

    mafia.members.push(interaction.user.id);
    await mafia.save();
    user.mafiaId = mafia.mafiaId;
    await user.save();

    await interaction.editReply({
      embeds: [mafiaEmbed(`${Emojis.MAFIA} Te uniste a ${mafia.name}`, [
        `**Líder:** <@${mafia.leaderId}>`,
        `**Miembros:** ${mafia.members.length}/${Config.MAFIA_MAX_MEMBERS}`,
        `**Descripción:** ${mafia.description}`,
      ].join("\n"))],
    });
  },
} satisfies Command;
