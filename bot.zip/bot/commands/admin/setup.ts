import { SlashCommandBuilder, ChatInputCommandInteraction, PermissionFlagsBits, ChannelType } from "discord.js";
import { getGuild } from "../../database/models/Guild";
import { successEmbed, errorEmbed, infoEmbed } from "../../lib/embeds";
import { Emojis } from "../../config";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("setup")
    .setDescription("Configura el bot para este servidor")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((sub) =>
      sub.setName("logs").setDescription("Canal de logs")
        .addChannelOption((o) => o.setName("canal").setDescription("Canal de logs").addChannelTypes(ChannelType.GuildText).setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName("verificacion").setDescription("Canal y rol de verificación")
        .addChannelOption((o) => o.setName("canal").setDescription("Canal de verificación").addChannelTypes(ChannelType.GuildText).setRequired(true))
        .addRoleOption((o) => o.setName("rol").setDescription("Rol de verificado").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName("tickets").setDescription("Rol de soporte para tickets")
        .addRoleOption((o) => o.setName("rol").setDescription("Rol de soporte").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName("bienvenida").setDescription("Canal de bienvenida")
        .addChannelOption((o) => o.setName("canal").setDescription("Canal de bienvenida").addChannelTypes(ChannelType.GuildText).setRequired(true))
        .addStringOption((o) => o.setName("mensaje").setDescription("Mensaje ({user}, {server}, {memberCount})").setRequired(false))
    )
    .addSubcommand((sub) =>
      sub.setName("ver").setDescription("Ver configuración actual")
    ),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply({ ephemeral: true });

    const sub = interaction.options.getSubcommand();
    const config = await getGuild(interaction.guild.id);

    if (sub === "logs") {
      const channel = interaction.options.getChannel("canal", true);
      config.logChannel = channel.id;
      await config.save();
      await interaction.editReply({ embeds: [successEmbed("Logs Configurado", `Canal de logs: <#${channel.id}>`)] });
    } else if (sub === "verificacion") {
      const channel = interaction.options.getChannel("canal", true);
      const role = interaction.options.getRole("rol", true);
      config.verifyChannel = channel.id;
      config.verifyRole = role.id;
      await config.save();
      await interaction.editReply({ embeds: [successEmbed("Verificación Configurada", `Canal: <#${channel.id}>\nRol: <@&${role.id}>`)] });
    } else if (sub === "tickets") {
      const role = interaction.options.getRole("rol", true);
      config.ticketSupportRole = role.id;
      await config.save();
      await interaction.editReply({ embeds: [successEmbed("Tickets Configurado", `Rol de soporte: <@&${role.id}>`)] });
    } else if (sub === "bienvenida") {
      const channel = interaction.options.getChannel("canal", true);
      const message = interaction.options.getString("mensaje");
      config.welcomeChannel = channel.id;
      if (message) config.welcomeMessage = message;
      await config.save();
      await interaction.editReply({ embeds: [successEmbed("Bienvenida Configurada", `Canal: <#${channel.id}>`)] });
    } else if (sub === "ver") {
      const embed = infoEmbed("Configuración Actual", [
        `${Emojis.LOG} **Logs:** ${config.logChannel ? `<#${config.logChannel}>` : "No configurado"}`,
        `${Emojis.CHECK} **Verificación:** ${config.verifyChannel ? `<#${config.verifyChannel}>` : "No configurado"}`,
        `${Emojis.SHIELD} **Rol Verificado:** ${config.verifyRole ? `<@&${config.verifyRole}>` : "No configurado"}`,
        `${Emojis.TICKET} **Soporte Tickets:** ${config.ticketSupportRole ? `<@&${config.ticketSupportRole}>` : "No configurado"}`,
        `${Emojis.STAR} **Bienvenida:** ${config.welcomeChannel ? `<#${config.welcomeChannel}>` : "No configurado"}`,
      ].join("\n"));
      await interaction.editReply({ embeds: [embed] });
    }
  },
} satisfies Command;
