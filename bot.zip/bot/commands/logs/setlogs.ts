import { SlashCommandBuilder, ChatInputCommandInteraction, PermissionFlagsBits, ChannelType } from "discord.js";
import { getGuild } from "../../database/models/Guild";
import { successEmbed } from "../../lib/embeds";
import { Emojis } from "../../config";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("setlogs")
    .setDescription("Configura el canal de logs del bot")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addChannelOption((o) =>
      o.setName("canal").setDescription("Canal donde se enviarán los logs").addChannelTypes(ChannelType.GuildText).setRequired(true)
    ),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply({ ephemeral: true });

    const channel = interaction.options.getChannel("canal", true);
    const config = await getGuild(interaction.guild.id);
    config.logChannel = channel.id;
    await config.save();

    await interaction.editReply({
      embeds: [successEmbed(`${Emojis.LOG} Logs Configurado`, `Los logs del bot se enviarán a <#${channel.id}>`)],
    });
  },
} satisfies Command;
