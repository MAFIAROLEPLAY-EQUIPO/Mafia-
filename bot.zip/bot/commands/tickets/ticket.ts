import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  EmbedBuilder,
  ChannelType,
} from "discord.js";
import { getGuild } from "../../database/models/Guild";
import { ticketEmbed, errorEmbed } from "../../lib/embeds";
import { Colors, Emojis } from "../../config";
import type { Command } from "../../types";

export default {
  data: new SlashCommandBuilder()
    .setName("ticket")
    .setDescription("Sistema de tickets")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((sub) =>
      sub.setName("panel").setDescription("Enviar panel de tickets al canal actual")
    ),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!interaction.guild) return;
    await interaction.deferReply({ ephemeral: true });

    const sub = interaction.options.getSubcommand();

    if (sub === "panel") {
      const embed = new EmbedBuilder()
        .setColor(Colors.PRIMARY)
        .setTitle(`${Emojis.TICKET} Centro de Soporte — Mafia Roleplay`)
        .setDescription(
          [
            "**¿Necesitas ayuda? Abre un ticket.**",
            "",
            `${Emojis.SHIELD} **Soporte General** — Dudas y ayuda general`,
            `${Emojis.WARN} **Reporte** — Reportar a un jugador`,
            `${Emojis.KEY} **Apelación** — Apelar una sanción`,
            `${Emojis.MONEY} **Negocios** — Acuerdos y negociaciones`,
            "",
            "> Selecciona la categoría en el menú de abajo.",
          ].join("\n")
        )
        .setFooter({ text: "Mafia Roleplay • Solo abrir tickets con razones válidas." })
        .setTimestamp();

      const menu = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId("ticket_category")
          .setPlaceholder("📂 Selecciona una categoría...")
          .addOptions([
            { label: "Soporte General", description: "Ayuda general del servidor", value: "soporte", emoji: "🛡️" },
            { label: "Reporte de Jugador", description: "Reportar comportamiento indebido", value: "reporte", emoji: "⚠️" },
            { label: "Apelación de Sanción", description: "Apelar un ban, mute u otra sanción", value: "apelacion", emoji: "🔑" },
            { label: "Negocios / Acuerdos", description: "Negociaciones entre mafias y jugadores", value: "negocios", emoji: "💵" },
          ])
      );

      await interaction.channel?.send({ embeds: [embed], components: [menu] });
      await interaction.editReply({ embeds: [ticketEmbed("Panel enviado", "El panel de tickets fue enviado correctamente.")] });
    }
  },
} satisfies Command;
