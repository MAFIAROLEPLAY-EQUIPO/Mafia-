import {
  StringSelectMenuInteraction,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
} from "discord.js";
import { Ticket } from "../database/models/Ticket";
import { errorEmbed } from "../lib/embeds";
import type { SelectMenu } from "../types";

export default {
  customId: "ticket_category",
  async execute(interaction: StringSelectMenuInteraction): Promise<void> {
    if (!interaction.guild) return;

    const existingTicket = await Ticket.findOne({ userId: interaction.user.id, guildId: interaction.guild.id, status: { $ne: "closed" } });
    if (existingTicket) {
      return void await interaction.reply({
        embeds: [errorEmbed("Ticket ya abierto", `Ya tienes un ticket abierto: <#${existingTicket.channelId}>`)],
        ephemeral: true,
      });
    }

    const category = interaction.values[0] as string;
    const labels: Record<string, string> = {
      soporte: "Soporte General",
      reporte: "Reporte de Jugador",
      apelacion: "Apelación de Sanción",
      negocios: "Negocios / Acuerdos",
    };

    const modal = new ModalBuilder()
      .setCustomId(`ticket_modal_${category}`)
      .setTitle(`📋 ${labels[category] ?? category}`);

    const subjectInput = new TextInputBuilder()
      .setCustomId("ticket_subject")
      .setLabel("Asunto del ticket")
      .setStyle(TextInputStyle.Short)
      .setPlaceholder("Describe brevemente tu problema...")
      .setMinLength(10)
      .setMaxLength(100)
      .setRequired(true);

    const detailInput = new TextInputBuilder()
      .setCustomId("ticket_detail")
      .setLabel("Descripción detallada")
      .setStyle(TextInputStyle.Paragraph)
      .setPlaceholder("Proporciona todos los detalles necesarios...")
      .setMinLength(20)
      .setMaxLength(1000)
      .setRequired(true);

    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(subjectInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(detailInput)
    );

    await interaction.showModal(modal);
  },
} satisfies SelectMenu;
